from flask import Flask, render_template, request, jsonify
import google.generativeai as genai
import requests
import os

app = Flask(__name__)

# Google Generative AI API 엔드포인트 및 API 키
#API_KEY = os.getenv('GOOGLE_API_KEY')  # .env 파일 또는 환경 변수로부터 읽기
API_KEY = "AIzaSyAdhxyDrqLe36vXLntLBnKTM195KZX6Jv0"  # 실제 API 키로 대체
genai.configure(api_key=API_KEY)

# 모델 초기화
try:
    model = genai.GenerativeModel('gemini-2.0-flash')
    #model = genai.get_model("gemini-2")
    chattest = model.start_chat(history=[])
except Exception as e:
    print("모델 초기화 중 오류 발생:", e)
    chattest = None

@app.route('/')
def home():
    return render_template('index.html')  # index.html 파일 준비 필수

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    
    #입력값 검증
    if not user_input or not isinstance(user_input, str):
        return jsonify({"error": "Invalid input format. Expected a non-empty string."}), 400
    
    try:
        # AI 모델과 통신
        response = chattest.send_message(user_input)
        bot_reply = response.text.split('\n')  # 응답을 항목별로 구분 (예: 줄바꿈 기준)

        print("Bot Reply:", bot_reply)
        return jsonify({"reply": "\n".join(bot_reply)})  # 각 항목을 줄바꿈으로 결합하여 전송
    
    except KeyError as e:
        print("KeyError 발생! 응답 데이터 확인:", response)
        return jsonify({"error": "Unexpected response format.", "details": str(e)}), 500

    except Exception as e:
        # 기타 예외 처리
        print("Error:", e)
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

# if __name__ == '__main__':
#     debug_mode = os.getenv("DEBUG", "False").lower() == "true"
#     app.run(debug=debug_mode)