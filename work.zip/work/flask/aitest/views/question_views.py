from flask import Blueprint, render_template, url_for, request, jsonify
from datetime import datetime
from werkzeug.utils import redirect
from aitest import db
from aitest.models import Question
import google.generativeai as genai
import requests
import os

bp = Blueprint('question', __name__, url_prefix='/question')
grpid = 1

# Google Generative AI API 엔드포인트 및 API 키
#API_KEY = os.getenv('GOOGLE_API_KEY')  # .env 파일 또는 환경 변수로부터 읽기
API_KEY = "AIzaSyAdhxyDrqLe36vXLntLBnKTM195KZX6Jv0"  # 실제 API 키로 대체
genai.configure(api_key=API_KEY)

# 모델 초기화
try:
    model = genai.GenerativeModel('gemini-2.0-flash')
    #model = genai.get_model("gemini-2")
    chattest = model.start_chat(history=[])
except Exception as e:
    print("모델 초기화 중 오류 발생:", e)
    chattest = None

@bp.route('/list/')
def _list():
    question_list = Question.query.order_by(Question.create_date.asc())
    return render_template('question/index.html', question_list=question_list)


@bp.route('/create/', methods=('POST',))
def create():
    qst = request.form['question']
    answer = request.form['answer']
    question = Question(grpid=grpid, question=qst, answer=answer, create_date=datetime.now())
    db.session.add(question)
    db.session.commit()
    return redirect(url_for('question._list'))