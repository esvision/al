from chat import db

class User(db.Model):
    __tablename__ = 'user'
    user_idx = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(200), nullable=False)
    create_date = db.Column(db.DateTime(), nullable=False)

class Chat(db.Model):
    __tablename__ = 'chat'
    chat_idx = db.Column(db.Integer, primary_key=True)
    user_idx = db.Column(db.Integer, db.ForeignKey('user.user_idx'), nullable=False)
    title = db.Column(db.Text(), nullable=False)
    start_date = db.Column(db.DateTime(), nullable=False)
    end_date = db.Column(db.DateTime(), nullable=False)

class Message(db.Model):
    __tablename__ = 'msg'
    msg_idx = db.Column(db.Integer, primary_key=True)
    chat_idx = db.Column(db.Integer, db.ForeignKey('chat.chat_idx'), nullable=False)
    sender= db.Column(db.String(20), nullable=False)
    content = db.Column(db.Text(), nullable=False)
    create_date = db.Column(db.DateTime(), nullable=False)

#######  flask -A aitest run
### flask -A aitest db init

### flask -A aitest db migrate
### flask -A aitest db upgrade
