from datetime import datetime
from werkzeug.utils import redirect
from chat import db
from chat.models import Chat, Message, User
from sqlalchemy.sql import func
from flask import Flask, Blueprint, render_template, url_for, request, jsonify
import google.generativeai as genai
import os

app = Flask(__name__)

# Google Generative AI API 설정
API_KEY = "AIzaSyAdhxyDrqLe36vXLntLBnKTM195KZX6Jv0"
genai.configure(api_key=API_KEY)

# 모델 초기화
try:
    model = genai.GenerativeModel('gemini-2.0-flash')
    chattest = model.start_chat(history=[])
except Exception as e:
    print("모델 초기화 중 오류 발생:", e)
    chattest = None

bp = Blueprint('question', __name__, url_prefix='/question')

@bp.route('/main/')
def main():
    return render_template('question/index.html')

@bp.route('/confirm/', methods=('POST',))
def confirm():
    # 유저 이메일 받아오기
    user_email = request.json.get('userEmail')
    
    if not user_email:
        return jsonify({"error": "email is required"}), 400
    
    # 유저 이메일 조회
    user = User.query.with_entities(User.user_idx, User.user_email).filter(User.user_email == user_email).first()
    
    # 유저 이메일이 없으면 빈 리스트 반환   
    if not user:
        return jsonify({
            "user_email": "",
            "ask_list": []
        }), 200

    user_idx = user.user_idx

    # 채팅 목록 조회
    title_list = (
        Chat.query
        .with_entities(
            Chat.chat_idx,
            Chat.user_idx,
            Chat.title
        )
        .filter(Chat.user_idx == user_idx)  # 사용자 ID로 필터링
        .order_by(Chat.chat_idx.desc())  # 채팅 ID 순서로 정렬
        .all()
    )
    
    # 조회 결과를 JSON 직렬화
    result = []
    for row in title_list:
        result.append({
            "chat_idx": row.chat_idx,
            "user_idx": row.user_idx,
            "title": row.title
        })

    print("Result ->", result)

    # 사용자 이름 포함 응답 반환
    return jsonify({
        "user_idx": user.user_idx,
        "user_email": user.user_email,
        "title_list": result
    })

@bp.route('/list/', methods=('POST',))
def _list():
    # 유저 이메일 받아오기
    user_email = request.json.get('userEmail')
    
    if not user_email:
        return jsonify({"error": "email is required"}), 400
    
    # 유저 이메일 조회
    user = User.query.with_entities(User.user_idx, User.user_email).filter(User.user_email == user_email).first()
    
    # 유저 이메일이 없으면 빈 리스트 반환   
    if not user:
        return jsonify({
            "user_email": "",
            "ask_list": []
        }), 200

    user_idx = user.user_idx

    # 채팅 목록 조회
    ask_list = (
        Chat.query
        .join(Message, Chat.chat_idx == Message.chat_idx)
        .join(User, Chat.user_idx == User.user_idx)
        .with_entities(
            Chat.chat_idx,
            Chat.title,
            Chat.start_date,
            Message.sender,
            Message.content,
            User.user_idx
        )
        .filter(User.user_idx == user_idx)  # 사용자 ID로 필터링
        .order_by(Chat.chat_idx.asc(), Message.msg_idx.asc())  # 채팅 ID와 메시지 순서로 정렬
        .all()
    )
    
    # 조회 결과를 JSON 직렬화
    result = []
    for row in ask_list:
        result.append({
            "chat_idx": row.chat_idx,
            "title": row.title,
            "start_date": row.start_date.strftime("%Y-%m-%d %H:%M:%S"),  # datetime 직렬화
            "sender": row.sender,
            "content": row.content,
            "user_idx": row.user_idx
        })

    print("Result ->", result)

    # 사용자 이름 포함 응답 반환
    return jsonify({
        "user_idx": user.user_idx,
        "user_email": user.user_email,
        "ask_list": result
    })

@bp.route('/create/', methods=('POST',))
def create():
    # POST 요청에서 이메일 가져오기    
    user_email = request.json.get('userEmail')

    if not user_email:
        return jsonify({"error": "Missing email parameter"}), 400

    existing_user = User.query.filter_by(user_email=user_email).first()
    if existing_user:
        return jsonify({"error": "User already exists."}), 400

    # 새 사용자 생성
    new_user = User(
        user_email=user_email,
        create_date=datetime.now()
    )
    db.session.add(new_user)
    db.session.commit()

    return jsonify({
        "user_idx": new_user.user_idx,  # Primary Key 반환
        "user_email": new_user.user_email,
        "create_date": new_user.create_date.strftime("%Y-%m-%d %H:%M:%S")
    })

@bp.route('/chat/', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        user_idx = data.get('userIdx')
        message = data.get('message')
        chat_idx = data.get('chatIdx')  # 현재 대화 인덱스 가져오기

        if not user_idx or not message:
            return jsonify({'error': 'Missing required parameters'}), 400

        # 새로운 대화인 경우 chat_idx 생성
        if not chat_idx:
            chat = Chat(user_idx=user_idx, title=message[:50], create_date=datetime.now())  # 첫 메시지의 앞부분을 제목으로 사용
            db.session.add(chat)
            db.session.commit()
            chat_idx = chat.chat_idx

        # 사용자 메시지 저장
        user_message = Message(
            chat_idx=chat_idx, 
            content=message, 
            sender='user',
            create_date=datetime.now()
        )
        db.session.add(user_message)
        db.session.commit()

        # AI 응답 생성
        bot_response = generate_response(message)  # 이 부분은 실제 AI 응답 생성 로직으로 대체해야 합니다

        # AI 응답 저장
        bot_message = Message(
            chat_idx=chat_idx, 
            content=bot_response, 
            sender='bot',
            create_date=datetime.now()
        )
        db.session.add(bot_message)
        db.session.commit()

        return jsonify({
            'bot_response': {'content': bot_response},
            'chat_idx': chat_idx  # 현재 대화 인덱스 반환
        })

    except Exception as e:
        print(f"Error in chat: {str(e)}")
        return jsonify({'error': 'An error occurred'}), 500

@bp.route('/load_chat/', methods=['POST'])
def load_chat():
    try:
        data = request.get_json()
        chat_idx = data.get('chat_idx')
        
        if not chat_idx:
            return jsonify({'error': 'Chat index is required'}), 400
            
        # 해당 채팅의 모든 메시지 가져오기
        messages = Message.query.filter_by(chat_idx=chat_idx).order_by(Message.msg_idx.asc()).all()
        
        # 메시지 데이터 구성
        messages_data = []
        for msg in messages:
            messages_data.append({
                'message': msg.content,
                'sender': 'user' if msg.sender == 'user' else 'bot'
            })
            
        return jsonify({'messages': messages_data})
        
    except Exception as e:
        print(f"Error loading chat: {str(e)}")
        return jsonify({'error': 'Failed to load chat history'}), 500

def get_next_user_idx():
    max_user_idx= db.session.query(func.max(User.user_idx)).scalar()  # 최대 값을 확인
    return (max_user_idx or 0) + 1  # max_user_idx가 None이면 0으로 대체

def generate_response(message, chat_idx):
    try:
        # 이전 대화 내역 조회
        previous_messages = Message.query.filter_by(chat_idx=chat_idx).order_by(Message.msg_idx.asc()).all()
        
        # 이전 대화 내역을 포함한 전체 대화 구성
        full_conversation = []
        for msg in previous_messages:
            if msg.sender == 'user':
                full_conversation.append(f"User: {msg.content}")
            else:
                full_conversation.append(f"Assistant: {msg.content}")
        
        # 현재 메시지 추가
        full_conversation.append(f"User: {message}")
        
        # 전체 대화를 하나의 문자열로 합치기
        conversation_text = "\n".join(full_conversation)
        
        # AI 모델과 통신 (이전 대화 내역 포함)
        response = chattest.send_message(conversation_text)
        print("Full response object:", response)
        print("Response type:", type(response))
        print("Response attributes:", dir(response))

        # response 구조 확인 및 텍스트 추출
        reponse_msg = ""
        response_parts = []
        
        # candidates 속성 확인
        if hasattr(response, "candidates"):
            for candidate in response.candidates:
                if hasattr(candidate, "content"):
                    if hasattr(candidate.content, "parts"):
                        for part in candidate.content.parts:
                            if hasattr(part, "text"):
                                response_parts.append(part.text)
                    elif hasattr(candidate.content, "text"):
                        response_parts.append(candidate.content.text)
        
        # 직접 text 속성이 있는 경우
        elif hasattr(response, "text"):
            response_parts.append(response.text)
        
        # parts 속성이 있는 경우
        elif hasattr(response, "parts"):
            for part in response.parts:
                if hasattr(part, "text"):
                    response_parts.append(part.text)
        
        # 다른 가능한 속성들 확인
        else:
            if hasattr(response, "__dict__"):
                for key, value in response.__dict__.items():
                    if isinstance(value, str):
                        response_parts.append(value)
                    elif hasattr(value, "text"):
                        response_parts.append(value.text)
                    elif isinstance(value, list):
                        for item in value:
                            if hasattr(item, "text"):
                                response_parts.append(item.text)

        # 원래 순서대로 텍스트 결합
        reponse_msg = "\n".join(response_parts)
        print("Extracted response:", reponse_msg)

        # 응답이 비어있는지 확인
        if not reponse_msg or reponse_msg.strip() == "":
            reponse_msg = "No response received from the bot."

        # 응답 포맷팅
        formatted_response = []
        lines = reponse_msg.split('\n')
        current_list = []
        
        for line in lines:
            line = line.strip()
            # ** 제거
            line = line.replace('**', '')
            if not line:
                if current_list:
                    formatted_response.append('\n'.join(current_list))
                    current_list = []
                formatted_response.append('')
                continue
                
            # 코드 블록 감지
            if line.startswith('```'):
                if current_list:
                    formatted_response.append('\n'.join(current_list))
                    current_list = []
                formatted_response.append('')
                continue
                
            # 리스트 항목 감지
            if line.startswith('- ') or line.startswith('* '):
                current_list.append(line)
            # 제목 감지
            elif line.startswith('# '):
                if current_list:
                    formatted_response.append('\n'.join(current_list))
                    current_list = []
                formatted_response.append(line[2:].strip())
                formatted_response.append('')
            # 일반 텍스트
            else:
                if current_list:
                    formatted_response.append('\n'.join(current_list))
                    current_list = []
                formatted_response.append(line)

        # 마지막 리스트 처리
        if current_list:
            formatted_response.append('\n'.join(current_list))

        # 빈 줄 제거 및 정리
        reponse_msg = '\n'.join(line for line in formatted_response if line.strip())

        if not reponse_msg:
            reponse_msg = "No response received from the bot."

        return reponse_msg

    except Exception as e:
        print(f"Error generating response: {str(e)}")
        return "An error occurred while generating the response."