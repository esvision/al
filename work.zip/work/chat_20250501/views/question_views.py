from datetime import datetime
from werkzeug.utils import redirect
from chat import db
from chat.models import Chat, Message, User
from sqlalchemy.sql import func
from flask import Flask, Blueprint, render_template, url_for, request, jsonify
import google.generativeai as genai
import requests
import os

app = Flask(__name__)

# Google Generative AI API 엔드포인트 및 API 키
#API_KEY = os.getenv('GOOGLE_API_KEY')  # .env 파일 또는 환경 변수로부터 읽기
API_KEY = "AIzaSyAdhxyDrqLe36vXLntLBnKTM195KZX6Jv0"  # 실제 API 키로 대체
genai.configure(api_key=API_KEY)

# 모델 초기화
try:
    model = genai.GenerativeModel('gemini-2.0-flash')
    #model = genai.get_model("gemini-2")
    chattest = model.start_chat(history=[])
except Exception as e:
    print("모델 초기화 중 오류 발생:", e)
    chattest = None

bp = Blueprint('question', __name__, url_prefix='/question')
grpid = 1

@bp.route('/main/')
def main():
    return render_template('question/index.html')

@bp.route('/list/', methods=('POST',))
def _list():
    # POST 요청에서 이메일 가져오기
    user_email = request.json.get('userEmail')  # JSON 데이터에서 email 가져오기
    print("user_email===", user_email)

    # 유효한 이메일인지 확인
    if not user_email:
        return jsonify({"error": "email is required"}), 400

    # 사용자 확인
    user = User.query.with_entities(User.user_idx,User.user_email).filter(User.user_email == user_email).first()

    print("user===", user)

    if not user:
        # 사용자 이메일이 등록되지 않은 경우
        return jsonify({
            "user_email": "",  # 사용자 이름 비어 있음
            "ask_list": []  # 대화 리스트도 비어 있음
        }), 200  # 상태코드 200으로 정상 응답, 클라이언트에서 처리

    # 사용자 ID
    user_idx = user.user_idx

    print("user_idx===", user_idx)

    # 조회 결과를 JSON 직렬화
    ask_list = (
        Chat.query
        .join(Message, Chat.chat_idx == Message.chat_idx)  # Chat과 Message 조인
        .join(User, Chat.user_idx == User.user_idx)        # Chat과 User 조인
        .with_entities(
            Chat.chat_idx,
            Chat.title,
            Chat.start_date,
            Message.sender,
            Message.content,
            User.user_idx
        )
        .filter(User.user_idx == user_idx)  # 사용자 ID로 필터링
        .order_by(Chat.chat_idx.asc(), Message.msg_idx.asc())  # 채팅 ID와 메시지 순서로 정렬
        .all()
    )
    
    # 조회 결과를 JSON 직렬화
    result = []
    for row in ask_list:
        result.append({
            "chat_idx": row.chat_idx,
            "title": row.title,
            "start_date": row.start_date.strftime("%Y-%m-%d %H:%M:%S"),  # datetime 직렬화
            "sender": row.sender,
            "content": row.content,
            "user_idx": row.user_idx
        })

    print("Result ->", result)

    # 사용자 이름 포함 응답 반환
    return jsonify({
        "user_idx": user.user_idx,  # user_idx
        "user_email": user.user_email,  # user_email
        "ask_list": result
    })

@bp.route('/create/', methods=('POST',))
def create():
    # POST 요청에서 이메일 가져오기    
    user_email = request.json.get('userEmail')
    print("create email===", user_email)

    if not user_email:
        return jsonify({"error": "Missing email parameter"}), 400

    existing_user = User.query.filter_by(user_email=user_email).first()
    if existing_user:
        return jsonify({"error": "User already exists."}), 400

    # 새 사용자 생성
    new_user = User(
        user_email=user_email,
        create_date=datetime.now()
    )
    db.session.add(new_user)
    db.session.commit()

    return jsonify({
        "user_idx": new_user.user_idx,  # Primary Key 반환
        "user_email": new_user.user_email,
        "create_date": new_user.create_date.strftime("%Y-%m-%d %H:%M:%S")
    })

@bp.route('/chat/', methods=['POST'])
def chat():
    data = request.json  # 받은 JSON 데이터를 가져옵니다.
    user_idx = data.get('userIdx')  # 'userId' 값 추출
    message = data.get('message')  # 'message' 값 추출

    #입력값 검증
    if not user_idx or not isinstance(user_idx, str) or not message or not isinstance(message, str):
        return jsonify({"error": "Invalid input format. Expected a non-empty string."}), 400
    
    new_msg = Chat(user_idx=user_idx,title=message,start_date=datetime.now(),end_date=datetime.now())
    
    db.session.add(new_msg)
    db.session.commit()

    print(new_msg.chat_idx)
    user_chat_idx = new_msg.chat_idx

    reponse_msg = None  # 초기화
    bot_reply = None  # 초기화

    try:
        # AI 모델과 통신
        response = chattest.send_message(message)

        print(response)         # 전체 response 객체 출력
        print(dir(response))    # response 객체의 가능한 속성 출력

        # response 구조 확인 및 텍스트 추출
        if hasattr(response, "text"):
            reponse_msg = response.text
        elif hasattr(response, "parts") and isinstance(response.parts, list):
            # 각 part의 text 속성을 가져와 하나의 문자열로 병합
            reponse_msg = "\n".join(part.text for part in response.parts if hasattr(part, "text"))
        else:
            reponse_msg = str(response)  # fallback to string representation

        print(f"Bot reply: {reponse_msg}")  # 추출된 답변 확인용 출력

        # 비어 있으면 기본 메시지 설정
        if not reponse_msg:
            reponse_msg = "No response received from the bot."

        # 4. 사용자의 메시지와 AI의 응답을 데이터베이스에 저장
        try:
            user_message = Message(
                chat_idx=user_chat_idx,
                sender='user',  # 사용자 메시지
                content=message,
                create_date=datetime.now()
            )
            bot_response = Message(
                chat_idx=user_chat_idx,
                sender='bot',   # 봇 응답
                content=reponse_msg,
                create_date=datetime.now()
            )

            db.session.add(user_message)
            db.session.add(bot_response)
            db.session.commit()

            bot_reply = bot_response.content.split('\n') 
            #bot_reply = bot_response.content

            print("Bot Reply:", bot_reply)

        except Exception as db_error:
            print(f"Database error: {str(db_error)}")

        # 5. 클라이언트로 응답 반환
        return jsonify({
            "chat_idx": user_chat_idx,
            "user_message": {
                "content": user_message.content,
                "create_date": user_message.create_date.strftime("%Y-%m-%d %H:%M:%S")
            },
            "bot_response": {
                "content": "\n".join(bot_reply),
                "create_date": bot_response.create_date.strftime("%Y-%m-%d %H:%M:%S")
            }
        })
    
    except KeyError as e:
        print("KeyError 발생! 응답 데이터 확인:", response)
        return jsonify({"error": "Unexpected response format.", "details": str(e)}), 500

    except Exception as e:
        # 기타 예외 처리
        print("Error:", e)
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

def get_next_user_idx():
    max_user_idx= db.session.query(func.max(User.user_idx)).scalar()  # 최대 값을 확인
    return (max_user_idx or 0) + 1  # max_user_idx가 None이면 0으로 대체